<template>
  <div class="index">
    <div class="logo"></div>
    <div class="enter-cont">
      <div class="enyet-cont-item">
        <img src="../../../assets/images/icon-phone.png" alt class="enyet-cont-item-icon">
        <input type="tel" v-model="phoneval" maxlength="11" class="enyet-cont-item-input" placeholder="输入手机号">
      </div>
      <div class="enyet-cont-item">
        <img src="../../../assets/images/icon-code.png" alt class="enyet-cont-item-icon big_icon">
        <input type="tel" style="width:120px" maxlength="6" v-model="codeval" class="enyet-cont-item-input" placeholder="验证码">
        <div class="getcode" @click="getCode" style="width:60%" v-if="btnBol">获取验证码</div>
        <div class="getcode" v-else>{{downTime}}秒</div>
      </div>
      <div class="enyet-cont-item">
        <img src="../../../assets/images/pass-icon.png" alt class="enyet-cont-item-icon big_icon">
        <input type="password" v-model="passwordval" class="enyet-cont-item-input" placeholder="输入新密码">
      </div>
      <div class="login_btn" @click="resetPasswordFn">确定</div>
      <div class="index-info">
        <span @click="goRegistered">注册账号</span> l
        <span @click="gologin">登录账号</span>
      </div>
    </div>
    <div class="trademark">苏州保时科技有限公司</div>
  </div>
</template>

<script>
import { UserReset,Sms } from "../../../axios/api.js";
export default {
  data() {
    return {
      phoneval: "", //电话好吗
      codeval: "", //验证码
      passwordval: "", //密码
      downTime: 60, //倒计时
      btnBol: true
    };
  },
  created() {},
  methods: {
    //   到登陆页面
    gologin() {
      this.$router.push({
        path: "/Login"
      });
    },
    goRegistered(){
      this.$router.push({
        path: '/Registered'
      })
    },
    // 验证码倒计时
    downTimeFn(val) {
      this.btnBol = false;
      setTimeout(() => {
        val--;
        this.downTime = val;
        if (val > 0) {
          this.downTimeFn(val);
        } else {
          this.btnBol = true;
        }
      }, 1000);
    },
     // 获取验证码
    getCode(){
       if(!!!this.phoneval){
         this.$vux.loading.show({
            text: '请输入手机号码'
          })
        setTimeout(()=>{
           this.$vux.loading.hide()
            },1000)
            return;
          }
        this.downTimeFn(60) 
        let data = {
          tel:this.phoneval
        }
        Sms(data).then(res=>{
           this.$vux.loading.show({
            text: res.Msg
            })
            setTimeout(()=>{
              this.$vux.loading.hide()
            },1000)
        })
    },
    // 重设密码
    resetPasswordFn(){
       if(!!!this.phoneval){
        this.$vux.loading.show({
        text: '请输入手机号码'
        })
        setTimeout(()=>{
          this.$vux.loading.hide()
        },1000)
        return;
      }
       if(!!!this.codeval){
        this.$vux.loading.show({
        text: '请输入验证码'
        })
        setTimeout(()=>{
          this.$vux.loading.hide()
        },1000)
        return;
      }
       if(!!!this.passwordval){
          this.$vux.loading.show({
            text: '请输入密码'
          })
        setTimeout(()=>{
          this.$vux.loading.hide()
        },1000)
         return;
      }
      let data = {
        "Tel": this.phoneval,
        "Pwd": this.passwordval,
        "YZM": this.codeval
      }
      UserReset(data).then(res=>{
        this.$vux.loading.show({
            text: res.Msg
          })
        setTimeout(()=>{
          this.$vux.loading.hide();
           if(res.Code == '200'){
             this.$router.push({
              path: "/Login"
            });
           }
        },1000)
      })
    }
  }
};
</script>

<style scoped>
.index {
  width: 100%;
  min-height: 100vh;
  background: url("../../../assets/images/login-bg.png") no-repeat;
  background-size: 100% 100%;
  box-sizing: border-box;
  padding: 1.33rem 0 0.933333rem;
  position: relative;
}
.logo {
  width: 2.48rem;
  height: 2.48rem;
  border-radius: 50%;
  margin: 0 auto;
  background: url("../../../assets/images/logo.png") no-repeat;
  background-size: 100% 100%;
}
.enter-cont {
  width: 100%;
  margin-top: 3rem;
  box-sizing: border-box;
  padding: 0 0.93rem;
}
.enyet-cont-item {
  width: 100%;
  height: 1.813333rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #eee
}
.enyet-cont-item-icon {
  width: 0.373333rem;
  height: auto;
}
.enyet-cont-item-input {
  flex: 1;
  box-sizing: border-box;
  padding: 0 0.533333rem;
  font-size: 0.426667rem;
  color: #999;
  font-family: "黑体";
  outline: none;
  border: none;
}
.enyet-cont-item-label {
  flex: 1;
  box-sizing: border-box;
  padding: 0 0.533333rem;
  font-size: 0.293333rem;
  color: #999;
  font-family: "黑体";
}
.enyet-cont-item-checkbox {
  width: .4rem;
  height: .4rem;
  border-radius: 0;
  outline: none;
}
.login_btn {
  width: 5.973333rem;
  height: 1.173333rem;
  margin: 0.533333rem auto 0;
  background: url("../../../assets/images/login-btn.png") no-repeat;
  background-size: 100% auto;
  border-radius: 1.173333rem;
  overflow: hidden;
  font-size: 0.48rem;
  color: #fff;
  text-align: center;
  line-height: 1.173333rem;
}
.index-info {
  width: 100%;
  text-align: center;
  font-size: 0.373333rem;
  color: #477bff;
  margin-top: 0.4rem;
}
.trademark {
  width: 100%;
  height: 0.933333rem;
  box-sizing: border-box;
  font-size: 0.32rem;
  color: #4679ff;
  text-align: center;
  padding-bottom: 0.533333rem;
  position: absolute;
  left: 0;
  bottom: 0;
}
.getcode {
  /* width: 1.866667rem; */
  width: 4rem;
  text-align: center;
  height: 0.64rem;
  text-align: center;
  line-height: 0.64rem;
  font-size: 0.293333rem;
  color: #999;
  background-color: #ebebeb;
  border-radius: 0.16rem;
}
.big_icon {
  width: 0.42rem;
}
</style>
